function open_sidebar() {
    document.getElementById("sidebar")
    document.getElementById("sidebar").style.display = "block";
}
function close_sidebar() {
    document.getElementById("sidebar").style.display = "none";
}

function saveForm(){
	var formData = {}; 						
    formData.roomNumber = location.search.split("room=")[1];
    formData.roomStatus = event.target.id; 
	// check we're getting what we hope for
    console.log('roomNum = ', formData.roomNumber);
    console.log('roomStat = ',formData.roomStatus);
	setObject('formData', formData);				// store data locally
	var storedData = getObject('formData');		// get it back
    console.log('r_num =', storedData.roomNumber);	// print
    console.log('r_stat =', storedData.roomStatus); //print
};

function postroomstatus(disp_id){
    var storedData;
    saveForm(); // save form again
    storedData = getObject('formData');
    post('http://localhost:8081/change_status', storedData, disp_id);
};


function post(path, data, disp_id) {

    // convert parameters in to a JSON data string
    var json = JSON.stringify(data);

    $.ajax({
        url: path,
        type: "POST",
        data: json,
            success: function(rt) {
                var json = JSON.parse(rt);
              
            window.location.replace('/Housekeeping.html');
        },
            error: function(){
                alert("Alert error");
            }
    });
}


function getRoomStatus() {

    $.ajax({
        url: "http://localhost:8081/get_status",
        type: "GET", // not submitting any data, so best to use GET
            success: function(rt) {
                var json = JSON.parse(rt);
                // Cycle through all database returned rows
                $.each(json, function(i,row) {
                  // Get data from current row
                  var roomNo = row["r_no"];
                  var roomStatus = row["r_status"];
                  if(!roomNo) {
                    console.log('No room number found for row', row);
                    return;
                  }
                  
                  // Find relevant element in HTML for room no
                  var roomDetailsElement = $('#'+roomNo);
                  // Check element with this ID
                  // By checking length of jQuery selector result,
                  if(roomDetailsElement.length > 0) {
                    // If exists then:
                    // Change text depending on roomStatus
                    switch(roomStatus) {
                      case 'A':
                        roomDetailsElement.html("Available");
                        break;
                      case 'X':
                        roomDetailsElement.html("Unavailable");
                        break;
                      case 'C':
                        roomDetailsElement.html("Checked out");
                        break;
                      default:
                        roomDetailsElement.html("UNKNOWN");
                    }
                } else {
                    // or error
                    console.log("problem updating room", roomNo, row);
                  }
                  
                })
            },
            
            error: function(){
                alert("Alert error");
            }
    });
    
}

$(document).ready(function() {
        getRoomStatus();
    });