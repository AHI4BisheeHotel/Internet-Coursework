 $(function() {
        var storage = JSON.parse(localStorage.getItem("hotel_data"));

        $("#bref").text(storage.bref);
        $(".adults").text(storage.adultcount);
        $(".child").text(storage.childcount);
        $("#checkin").text(new Date(storage.checkindate).toDateString());
        $("#checkout").text(new Date(storage.checkoutdate).toDateString());
        $(".rooms").text(storage.numberOfRooms);
        $(".nights").text(storage.numberOfNights);
        $(".name").text(storage.name);
        $(".single-price").text(storage.pricePerNight);
        $(".total-price").text(storage.price);
        $(".price").text( Number(storage.numberOfNights) * Number(storage.pricePerNight));
        if(storage.breakfast) {
          $(".BREAKFAST").show();
          $(".food-price").text( Number(storage.numberOfNights) * 10);
        }
      });