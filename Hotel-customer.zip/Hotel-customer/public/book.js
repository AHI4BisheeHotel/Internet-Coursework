$(function() {
			var daysBetween = function(d1, d2) {
				var date1 = new Date(d1);
				var date2 = new Date(d2);
				var timeDiff = Math.abs(date2.getTime() - date1.getTime());
				return Math.ceil(timeDiff / (1000 * 3600 * 24)); 
			};

			var createTable = function(d1, d2, room, table, avail) {
				var roomName; 

				var options = "";
				for(var i = 1; i <= avail; i++) options += '<option value="'+i+'">'+i+'</option>';
				var numberOfNights = daysBetween(d1, d2); 

				switch(room.r_class) {
					case "std_d": roomName = "Single Double Room"; break;
					case "sup_d": roomName = "Large Double Room"; break;
					case "std_t": roomName = "Single Twin Room"; break;
					case "sup_t": roomName = "Large Twin Room"; break;
				}

	    		var regularPrice = room.price * numberOfNights;
	    		var breakfastPrice = (Number(room.price) + 10) * numberOfNights;

	    		$(table).find("tbody").prepend(
		    		'<tr>\
						<td>'+ roomName + '</td>\
						<td>Options</td>\
						<td>Price for ' + numberOfNights +' Nights</td>\
						<td>No Of Rooms</td>\
						<td>Action</td>\
					</tr>\
					<tr>\
						<td rowspan="2">\
							<img src="images/room2.jpg" alt="" width="250" height="150">\
							<p style="margin-bottom: 4px">One Double Bed</p>\
							<p style="margin-bottom: 4px">Free Wifi</p>\
							<p style="margin-bottom: 4px">T.V</p>\
							<p style="margin-bottom: 4px">Handdryer</p>\
						</td>\
						<td>Breakfast £ 10</td>\
						<td>GBP ' + regularPrice + '</td>\
						<td><select name="" id="">\
							<option value=""></option>'+options+'\
						</select></td>\
						<td><button class="btn btn-warning book-button" data-rtype='+room.r_class+' data-price='+regularPrice+' data-bf="false" data-sprice='+room.price+'>Book</button></td>\
					</tr>\
					<tr>\
						<td>\
						<p style="margin-bottom: 10px">Breakfast Included</p>\
						<p style="margin-bottom: 10px">Hot tub</p>\
						<p style="margin-bottom: 10px">Free Cancellation</p>\
						</td>\
						<td>GBP ' + breakfastPrice + '</td>\
						<td><select name="" id="">\
							<option value=""></option>'+options+'\
						</select></td>\
						<td><button class="btn btn-warning book-button" data-rtype='+room.r_class+' data-price='+breakfastPrice+' data-bf="true" data-sprice='+room.price+'>Book</button></td>\
					</tr>');
			};


			$("form#form").on('submit', function(e) {
				e.preventDefault();
				if(Number($("#adultcount").val()) > 2 ) {
					alert("Maximum Adults in a room is 2");
					return;
				}

				$("tbody").html("");

				var storageData = {
					room: $("#room").val(),
					checkindate: $("#checkindate").val(),
					checkoutdate: $("#checkoutdate").val(),
					childcount: $("#childcount").val(),
					adultcount: $("#adultcount").val(),
				};

				console.log(storageData);

				fetch("http://localhost:8080/check", { 
					method: "POST",
		            mode: "cors",
		            cache: "no-cache",
		            credentials: "same-origin",
		            headers: { "Content-Type": "application/x-www-form-urlencoded" },
		            redirect: "follow",
		            referrer: "no-referrer",
		            body: $.param(storageData)
				})
			    .then(function(response) { return response.json(); } ) // parses response to JSON
			    .then(function(res) {
			    	if(res.length == 0) {
			    		$(".main-results").show();
			    		$("#msg").text("Sorry, No rooms of your criteria, Try A different Date");
			    		return;
			    	}

			    	var grouped = res.reduce(function (r, a) {
				        r[a.r_class] = r[a.r_class] || [];
				        r[a.r_class].push(a);
				        return r;
				    }, Object.create(null));
			    	console.log(grouped);
			   
			    	var showDouble = function() {
			    		if(grouped['std_d']) 
			    			createTable(storageData.checkindate, storageData.checkoutdate, 
			    				grouped['std_d'][0], "#std-tbl", grouped['std_d'].length);
			    		if(grouped['sup_d']) 
			    			createTable(storageData.checkindate, storageData.checkoutdate, 
			    				grouped['sup_d'][0], "#sup-tbl", grouped['sup_d'].length);
			    	};

			    	var showTwin = function() {
			    		if(grouped['std_t']) 
			    			createTable(storageData.checkindate, storageData.checkoutdate, 
			    				grouped['std_t'][0], "#std-tbl", grouped['std_t'].length);
			    		if(grouped['sup_t']) 
			    			createTable(storageData.checkindate, storageData.checkoutdate, 
			    				grouped['sup_t'][0], "#sup-tbl", grouped['sup_t'].length);
			    	};
			    	

			    	if(storageData.room == 'double') {
			    		if(! grouped['std_d'] && ! grouped['sup_d']) {
			    			showTwin();
			    			$("#msg").text("Sorry, No rooms of your criteria, Here are alternatives");
			    		} else {
			    			showDouble();
			    			$("#msg").text("Top Results");
			    		}
			    	} else if(storageData.room == 'twin') {
			    		if(! grouped['std_d'] && ! grouped['sup_d']) {
			    			showDouble();
			    			$("#msg").text("Sorry, No rooms of your criteria, Here are alternatives");
			    		} else {
			    			showTwin();
			    			$("#msg").text("Top Results");
			    		}
			    	} 

			    	$(".main-results").show();

			    	$("button.book-button").on('click', function(evt) {
						var numberOfRooms = $($($(this).parent().parent()).find("select")).val();

						if(numberOfRooms == "" || !numberOfRooms) {
							alert("Enter No. Of Rooms");
							return;
						}

						var hasBreakfast = ($(this).data('bf') == 'true' || $(this).data('bf') == true) ? true : false;

						var rooms = [];
						var roomType = $(this).data('rtype');
						for(var i=0; i < numberOfRooms; i++) {
							rooms[i] = grouped[roomType][i].r_no;
						}

						var sData = Object.assign({}, storageData, {
							pricePerNight: $(this).data('sprice'),
							rooms: rooms,
							price: $(this).data('price'),
							numberOfRooms: numberOfRooms,
							numberOfNights: daysBetween(storageData.checkindate, storageData.checkoutdate),
							breakfast: hasBreakfast
						});

						localStorage.setItem("hotel_data", JSON.stringify(sData));

						location.assign("http://localhost:8080/customer.html");
					});	

			    });
			    	
			});
		});