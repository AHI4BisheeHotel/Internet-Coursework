var pg = require('pg')
var format = require('pg-format')
var PGUSER = 'groupbe'
var PGDATABASE = 'groupbe';
const connectionString = 'postgres://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';

var pool = new pg.Pool({
  connectionString: connectionString,
});


module.exports = {
  query: (text, params, callback) => {
    const start = Date.now()
    return pool.query(text, params, (err, res) => {
      const duration = Date.now() - start
      if(! err) {
        //console.log('executed query', { text, duration, rows: res.rowCount })  
      }
      callback(err, res)
    })
  }
}