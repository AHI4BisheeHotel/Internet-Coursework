var http = require('http');

process.on('uncaughtException', function (err) {
  console.error(err);
  console.log("Node NOT Exiting...");
});

http.createServer(function (req, res) {
    console.log(req.url)
    console.log(req.method)

    res.setHeader('Access-Control-Allow-Origin', '*');
 
    switch (req.url) {
        case '/change_status':
            if (req.method == 'POST') {
                console.log("POST");
                var body = '';
                req.on('data', function (data) {
                    body += data;
                    console.log("Partial body: " + body);
                });
                req.on('end', async function () {
                    console.log("Body: " + body);
                    var json = JSON.parse(body);
                    console.log("room number is " + json.roomNumber); //print roomNumber
                    console.log("status is " + json.roomStatus); //print status
                    json_str_new = JSON.stringify(json);
					const {Client} = require ('pg');
					const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
					const client = new Client({ 
					connectionString: connectionString
                    });
                    
					await client.connect();
					const text = 'UPDATE hotelbooking.room SET r_status= $1 WHERE r_no = $2 RETURNING *';
                    const values = [json.roomStatus, json.roomNumber];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var json_str_new = JSON.stringify(json);        
                    console.log(json_str_new);
                    res.end(json_str_new); // return modified data
					
                });
                
            }
            break;
            case '/get_status':
            
            if (req.method == 'GET') {
                console.log('get_status');
                var body = '';
                req.on('data', function (data) {
                    body += data;
                    console.log("Partial body: " + body);
                });
                req.on('end', async function () {
                    var json ;
                    const {Client} = require ('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';

                    const client = new Client({ 
                    connectionString: connectionString
                    });
                    await client.connect();
                    const res2 = await client.query('SELECT r_status, r_no FROM hotelbooking.room');
                    
                    await client.end();
                    json = res2.rows;
                    var json_str = JSON.stringify(json);        
                    res.end(json_str); // return modified data
                });
            
}

            break;
         
        default:
            res.writeHead(200, {'Content-Type': 'text/html'});
            res.end('error');
    }
 }).listen(8081); 
