$(function(){
    var url=window.location.pathname;  
    if((url === '/reception_page.html')){
        $("#login_name").html(getUserName());
        $("#cki_cun_all").html(getCheckNum("cki_cun_all"));
        $("#cki_cun_i").html(getCheckNum("cki_cun_i"));
        $("#cko_cun_all").html(getCheckNum("cko_cun_all")); 
        $("#cko_cun_O").html(getCheckNum("cko_cun_O"));
    }
    if(url === '/rec_checking_page.html'){
        var str = getButtonstatus();
        var storedData;
        saveCheckDefaultForm('str'); // save the form again just in case
        storedData = getObject('form3Data');
        switch(str){
            case 'cki_cun_all':
            defaultChecking_post('http://localhost:8081/get_defaultCheckData', storedData);
            break;
            case 'cki_cun_i':
            defaultChecking_post('http://localhost:8081/get_havenotchkin', storedData);
            break;
            case 'cko_cun_all':
            defaultChecking_post('http://localhost:8081/get_dchkoutData', storedData);
            break;
            case 'cko_cun_O':
            defaultChecking_post('http://localhost:8081/get_havenotchkout', storedData);
            break;
            case 'showdetail':
            getIdjson();
            detailChecking_post('http://localhost:8081/get_bookingdetail', getObject('form4Data'));
            break;

        }

    }

    })



function defaultChecking_post(path, data) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);
    $.ajax({
        url: path,
        type: "POST",
        data: json,
        success: function(rt) {
            $('#paid_button').empty();
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            var str = "";
            $.each(json, function(i,val) {
                var col = [];
                for (var i = 0; i < val.length; i++) {
                    for (var key in val[i]) {
                        if (col.indexOf(key) === -1) {
                            col.push(key);
                        }
                    }
                }
                var table = document.
                    createElement("table");
                    table.style.border="2px solid ";
                    table.style.borderColor="#B4955E";
                    table.width="90%";
                    var tr = table.insertRow(-1);           
            
                    for (var i = 0; i < col.length; i++) {
                        var th = document.createElement("th");   
                        th.innerHTML = col[i];
                        th.style.backgroundColor="#B4955E";
                        th.style.border="2px solid ";
                        th.style.borderColor="#B4955E";
                        th.style.color="#ffffff";
                        tr.appendChild(th);
                        tr.style.backgroundColor="#ffffff";
                        tr.style.border="2px solid ";
                        tr.style.borderColor="#B4955E";
                    }
                for (var i = 0; i < val.length; i++) {
                    tr = table.insertRow(-1);
                    for (var j = 0; j < col.length; j++) {
                        var tabCell = tr.insertCell(-1);
                        if(j==0){
                            tabCell.innerHTML='<a href="/rec_checking_page.html?status=showdetail&orderid='+val[i][col[j]]+'" name="checkin">'+val[i][col[j]]+'</a>';
                        }else{
                            tabCell.innerHTML = val[i][col[j]];
                        }
                    }
                }
                var divContainer = document.getElementById("b_table");
                divContainer.innerHTML = "";
                divContainer.appendChild(table);
            })
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });

};

function detailChecking_post(path, data) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);
    $.ajax({
        url: path,
        type: "POST",
        data: json,
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            var str ;
            var b_ref ;
            $.each(json, function(k,value1) {
                if(k=='paidstatus'){
                    $('#paid_status').append('Paid status : '+value1[k]!=0? 'NO YET PAID':'PAID');
                    str = value1[k];
                }
                if(k=='allcheckintable'){
                        var val = json['allcheckintable'];
                        var col = [];
                        for (var i = 0; i < val.length; i++) {
                            for (var key in val[i]) {
                                if (col.indexOf(key) === -1) {
                                    col.push(key);
                                }
                            }
                        }
                        col.push("Action");
                            var table = document.createElement("table");
                            table.style.border="2px solid ";
                            table.style.borderColor="#B4955E";
                            table.width="100%";
                            var tr = table.insertRow(-1);           
                    
                            for (var i = 0; i < col.length; i++) {
                                var th = document.createElement("th");   
                                th.innerHTML = col[i];
                                th.style.backgroundColor="#B4955E";
                                th.style.border="2px solid ";
                                th.style.borderColor="#B4955E";
                                th.style.color="#ffffff";
                                tr.appendChild(th);
                                tr.style.backgroundColor="#ffffff";
                                tr.style.border="2px solid ";
                                tr.style.borderColor="#B4955E";
                            }
                            tr.appendChild(th);
                            for (var i = 0; i < val.length; i++) {
                                tr = table.insertRow(-1);
                                for (var j = 0; j < col.length; j++) {
                                    var tabCell = tr.insertCell(-1);
                                    if(j==col.length-1){
                                        tabCell.innerHTML = val[i][col[j]];
                                        b_ref = val[i][col[0]];
                                        if(val[i][col[col.length-2]]=='I'){
                                            tabCell.innerHTML = 'CHECKED';
                                            tabCell.innerHTML = '<input type="hidden" value="'+val[i][col[0]]+'“ id="b_ref"><input type="hidden" value="'+val[i][col[4]]+'“ id="r_no"><input type="button" value="CHECK OUT" onclick="checkout('+val[i][col[0]]+','+val[i][col[4]]+')" >';
                                            
                                        }else if(val[i][col[col.length-2]]=='O'){
                                            tabCell.innerHTML = 'CHECKOUT';
                                            //tabCell.innerHTML = '<input type="hidden" value="'+val[i][col[0]]+'“ id="b_ref"><input type="hidden" value="'+val[i][col[4]]+'“ id="r_no"><input type="button" value="CHECK OUT" onclick="checkout('+val[i][col[0]]+','+val[i][col[4]]+')" >';
                                            
                                        }else{
                                            tabCell.innerHTML = '<input type="hidden" value="'+val[i][col[0]]+'“ id="b_ref"><input type="hidden" value="'+val[i][col[4]]+'“ id="r_no"><input type="button" value="CHECKIN" onclick="checkin('+val[i][col[0]]+','+val[i][col[4]]+')" >';
                                        }
                                    }else{
                                        if(j==4){
                                            tabCell.innerHTML = val[i][col[j]]+'<br/><input type="hidden" value="'+val[i][col[0]]+'“ id="b_ref"><input type="hidden" value="'+val[i][col[4]]+'“ id="r_no"><input type="button" value="Change Room" onclick="changeroom('+val[i][col[0]]+','+val[i][col[4]]+')" >';
                                        }else{
                                            tabCell.innerHTML = val[i][col[j]];
                                        }
                                        
                                    }
                                    
                                }
                            }
                        
                        var divContainer = document.getElementById("detail_table");
                        divContainer.innerHTML = "";
                        divContainer.appendChild(table);
                        if(str != '0'){
                            $('#paid_button').append('<input type="button" value="Pay bill" onclick="pay('+b_ref+')" >');
                        }
                }  
            })
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });

};
//go_home
function go_home(path, data) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);

    $.ajax({
        url: path,
        type: "POST",
        data: json,
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            var str = "";
            $.each(json, function(i,val) {
                    if(i ==='logininfo'){
                        $.each(val, function(x, val1) {
                            $.each(val1, function(y, val2) {
                                if(y==='emp_name'){
                                    str =y+"="+val2;
                                }
                            });
                        });
                    }
                    if(i ==='checkin＿all'){
                        $.each(val, function(x, val1) {
                            $.each(val1, function(y, val2) {
                                if(y==='cki_cun'){
                                    str +="&"+y+'_all'+"="+val2;
                                }
                            });
                        });
                    }
                    if(i ==='checkin＿i'){
                        $.each(val, function(x, val1) {
                            $.each(val1, function(y, val2) {
                                if(y==='cki_cun'){
                                    str +="&"+y+'_i'+"="+val2;
                                }
                            });
                        });
                    }
                    if(i ==='checkout_all'){
                        $.each(val, function(x, val1) {
                            $.each(val1, function(y, val2) {
                                if(y==='cko_cun'){
                                    str +="&"+y+'_all'+"="+val2;
                                }
                            });
                        });
                    }
                    if(i ==='checkout_o'){
                        $.each(val, function(x, val1) {
                            $.each(val1, function(y, val2) {
                                if(y==='cko_cun'){
                                    str +="&"+y+'_O'+"="+val2;
                                }
                            });
                        });
                    }
                    $('#gohome').append('/reception_page.html?'+str);
                    window.location.replace('/reception_page.html?'+str);
                
            })
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });

};

function getUserName(){
    var result;
    var url=window.location.search;  
    if(url.indexOf("?")!=-1){
    var parameter = (url.split("?")[1]).split("&")[0].split("=")[1];  
    result = (parameter).indexOf("%20")? parameter.replace("%20"," "):parameter;
    }else if(((url.split("?")[1]).split("&")[0].split("=")[0]).indexOf('status')!=-1){
        result = 'Ada Chen';
    }
    return result;
}

function getCheckNum(colname){
    var result;
    var arr=[];
    var url=window.location.search;  
    if(url.indexOf("?")!=-1){
            var parameter = (url.split("?")[1]);
            if(parameter.indexOf(colname) !=-1){
                parameter = parameter.substring(parameter.indexOf(colname),parameter.length);
                arr = parameter.split("&");
                result = ((arr[0]).split("="))[1];
            }else{
                result = "0";
            }
    }
    return result==""? "0": result;
}


function getButtonstatus(){
    var result;
    var url=window.location.search;  
    if(url.indexOf("?")!=-1){
        if(url.indexOf("&")==-1){
            result = url.split("=")[1];
        }else{
            result = (url.split("&")[0]).split("=")[1];
        }
    }
    return result;
}

function getIdjson(){
    var result;
    var url=window.location.search;  
    var form4Data = {}; 			
    form4Data.detailid = (url.split("&")[1]).split("=")[1];	
	setObject('form4Data', form4Data);				// store the data locally
	var storedData = getObject('form4Data');
}

function saveCheckDefaultForm(buttonstatus){
	var form3Data = {}; 			
	form3Data.buttonstatus = buttonstatus;	
	
	setObject('form3Data', form3Data);				// store the data locally
	var storedData = getObject('form3Data');		// get it back again...
};


function saveSearchForm(){
	var form2Data = {}; 			
	form2Data.sdata = $('#sdata').val();	
	form2Data.stype = $('input[name=stype]:checked').val();
	setObject('form2Data', form2Data);				// store the data locally
	var storedData = getObject('form2Data');		// get it back again...
};


function seachBooking(disp_id){
    var storedData;
    saveSearchForm(); // save the form again just in case
    storedData = getObject('form2Data');
    rec_search('http://localhost:8081/search_room', storedData, disp_id);
};

function rec_search(path, data, disp_id) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);
    $.ajax({
        url: path,
        type: "POST",
        data: json,
        //create table reference https://www.encodedna.com/javascript/populate-json-data-to-html-table-using-javascript.htm
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            $('#'+disp_id).empty();
            $.each(json, function(i,val) {
                if(i==='status'){
                    $('#'+disp_id).append('Could not find this booking');
                }
                if(i==='checkindata'){
                    var col = [];
                    for (var i = 0; i < val.length; i++) {
                        for (var key in val[i]) {
                            if (col.indexOf(key) === -1) {
                                col.push(key);
                            }
                        }
                    }
                    var table = document.
                    createElement("table");
                    table.style.border="2px solid ";
                    table.style.borderColor="#B4955E";
                    table.width="100%";
                    var tr = table.insertRow(-1);           
            
                    for (var i = 0; i < col.length; i++) {
                        var th = document.createElement("th");   
                        th.innerHTML = col[i];
                        th.style.backgroundColor="#B4955E";
                        th.style.border="2px solid ";
                        th.style.borderColor="#B4955E";
                        th.style.color="#ffffff";
                        tr.appendChild(th);
                        tr.style.backgroundColor="#ffffff";
                        tr.style.border="2px solid ";
                        tr.style.borderColor="#B4955E";
                    }
                    for (var i = 0; i < val.length; i++) {
                        tr = table.insertRow(-1);
                        for (var j = 0; j < col.length; j++) {
                            var tabCell = tr.insertCell(-1);
                            if(j==0){
                                tabCell.innerHTML='<a href="/rec_checking_page.html?status=showdetail&orderid='+val[i][col[j]]+'" name="checkin">'+val[i][col[j]]+'</a>';
                            }else{
                                tabCell.innerHTML = val[i][col[j]];
                            }
                        
                            
                        }
                    }
                    var divContainer = document.getElementById("change_table");
                    divContainer.innerHTML = "";
                    divContainer.appendChild(table);

                }//end checkindata
            })
        },
        error: function(){
            alert("System error,Please check your code");
        }


    });

};
//pay
function pay(b_ref){
    alert('pay');	
    var storedData;
    savepaydataForm(b_ref); // save the form again just in case
    storedData = getObject('form10Data');
    rec_pay_room('http://localhost:8081/pay_room', storedData);
};

function savepaydataForm(b_ref){
    var form10Data = {}; 		
    form10Data.pay_b_ref = b_ref;	
	setObject('form10Data', form10Data);				// store the data locally
};

function rec_pay_room(path, data) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);
    $('#paid_button').empty();
    $.ajax({
        url: path,
        type: "POST",
        data: json,
        //create table reference https://www.encodedna.com/javascript/populate-json-data-to-html-table-using-javascript.htm
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            var str="";
            $.each(json, function(i,val) {
                    var col = [];
                    for (var i = 0; i < val.length; i++) {
                        for (var key in val[i]) {
                            if (col.indexOf(key) === -1) {
                                col.push(key);
                            }
                        }
                    }
                    col.push('Action');
                    var table = document.
                    createElement("table");
                    table.style.border="2px solid ";
                    table.style.borderColor="#B4955E";
                    table.width="100%";
                    var tr = table.insertRow(-1);           
            
                    for (var i = 0; i < col.length; i++) {
                        var th = document.createElement("th");   
                        th.innerHTML = col[i];
                        th.style.backgroundColor="#B4955E";
                        th.style.border="2px solid ";
                        th.style.borderColor="#B4955E";
                        th.style.color="#ffffff";
                        tr.appendChild(th);
                        tr.style.backgroundColor="#ffffff";
                        tr.style.border="2px solid ";
                        tr.style.borderColor="#B4955E";
                        
                    }
                    
                    for (var i = 0; i < val.length; i++) {
                        tr = table.insertRow(-1);
                        for (var j = 0; j < col.length; j++) {
                            var tabCell = tr.insertCell(-1);
                            tabCell.innerHTML = val[i][col[j]];
                            if(j==0){
                                str = val[i][col[j]];
                            }
                            if(j==col.length-1){
                                tabCell.innerHTML = '<input type="button" value="Pay" onclick="paid('+str+')" >';
                            }else{
                                tabCell.innerHTML = val[i][col[j]];
                            }
                        }
                    }
                    
                    var divContainer = document.getElementById("pay_detail_table");
                    divContainer.innerHTML = "";
                    divContainer.appendChild(table);
            })
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });
};

//change room
function changeroom(b_ref,r_no){
    var storedData;
    savechangedataForm(b_ref,r_no); // save the form again just in case
    storedData = getObject('form5Data');
    rec_change_room('http://localhost:8081/change_room', storedData);
};

function savechangedataForm(b_ref,r_no){
    var form5Data = {}; 		
    form5Data.col_b_ref = b_ref;	
    form5Data.col_r_no = r_no;	
	setObject('form5Data', form5Data);				// store the data locally
};

function rec_change_room(path, data) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);
    $.ajax({
        url: path,
        type: "POST",
        data: json,
        //create table reference https://www.encodedna.com/javascript/populate-json-data-to-html-table-using-javascript.htm
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            $.each(json, function(i,val) {
                    var col = [];
                    for (var i = 0; i < val.length; i++) {
                        for (var key in val[i]) {
                            if (col.indexOf(key) === -1) {
                                col.push(key);
                            }
                        }
                    }
                    var table = document.
                    createElement("table");
                    table.style.border="2px solid ";
                    table.style.borderColor="#B4955E";
                    table.width="100%";
                    var tr = table.insertRow(-1);           
            
                    for (var i = 0; i < col.length; i++) {
                        var th = document.createElement("th");   
                        th.innerHTML = col[i];
                        th.style.backgroundColor="#B4955E";
                        th.style.border="2px solid ";
                        th.style.borderColor="#B4955E";
                        th.style.color="#ffffff";
                        tr.appendChild(th);
                        tr.style.backgroundColor="#ffffff";
                        tr.style.border="2px solid ";
                        tr.style.borderColor="#B4955E";
                    }
                    for (var i = 0; i < val.length; i++) {
                        tr = table.insertRow(-1);
                        for (var j = 0; j < col.length; j++) {
                            var tabCell = tr.insertCell(-1);
                            if(j==0){
                                tabCell.innerHTML='<input type="button" value="Switch Room" onclick="switchroom('+val[i][col[j]]+')" ><input type="hidden" value="'+val[i][col[j]]+'" id="r_no">'+val[i][col[j]];
                            }else{
                                tabCell.innerHTML = val[i][col[j]];
                            }    
                        }
                    }
                    var divContainer = document.getElementById("b_table");
                    divContainer.innerHTML = "";
                    divContainer.appendChild(table);
            })
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });
};

function switchroom(r_no){	
    var storedData;
    swithroom(r_no); // save the form again just in case
    storedData = getObject('form8Data');
    switch_room('http://localhost:8081/switchroom', storedData);
};

function swithroom(r_no){
    var form8Data = {}; 	
    var form5Data = getObject('form5Data')		
    form8Data.col_b_ref = form5Data.col_b_ref;	
    form8Data.col_r_no = form5Data.col_r_no;	
    form8Data.to_r_no = r_no;	
	setObject('form8Data', form8Data);				// store the data locally
	var storedData = getObject('form8Data');		// get it back again...
};

function switch_room(path, data) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);
    $.ajax({
        url: path,
        type: "POST",
        data: json,
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            window.location.replace(location.href)
            
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });

};

function checkin(b_ref,r_no){
    var storedData;
    savechangedataForm(b_ref,r_no); // save the form again just in case
    storedData = getObject('form5Data');
    checkinform('http://localhost:8081/checkin', storedData);
};

function checkinform(path, data) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);
    $.ajax({
        url: path,
        type: "POST",
        data: json,
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            window.location.replace(location.href)
            
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });

};
//check out
function sacecheckoutdate(b_ref,r_no){
    var form9Data = {}; 			
    form9Data.chko_b_ref = b_ref;	
    form9Data.chko_r_no = r_no;	
	setObject('form9Data', form9Data);					
};

function checkout(b_ref,r_no){	
    var storedData;
    sacecheckoutdate(b_ref,r_no); // save the form again just in case
    storedData = getObject('form9Data');
    checkoutform('http://localhost:8081/checkout', storedData);
};



function checkoutform(path, data) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);
    $.ajax({
        url: path,
        type: "POST",
        data: json,
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            window.location.replace(location.href)
            
        },
        error: function(){
            alert("System error,Please check your code");
        }


    });

};

//paid
function paid(b_ref){
    alert('paid-----'+b_ref);	
    var storedData;
    savepaiddataForm(b_ref); // save the form again just in case
    storedData = getObject('form11Data');
    rec_pay_room('http://localhost:8081/paid', storedData);
};

function savepaiddataForm(b_ref){
    var form11Data = {}; 		
    form11Data.pay_b_ref = b_ref;	
    setObject('form11Data', form11Data);		
};

function rec_paid(path, data) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);
    $('#paid_button').empty();
    $.ajax({
        url: path,
        type: "POST",
        data: json,
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); 
            window.location.reload();
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });
};

