$(function() {
        $("#next-button").on("click", function() {
          $("#main").hide();
          $("#payment").show();
        });

        $("#back-button").on("click", function() {
          $("#main").show();
          $("#payment").hide();
        });

        $("#submit-button").on("click", function() {
    	  if(! localStorage.getItem("hotel_data")) {
    		alert("Proceed to home page to properly book.");
    		return;
    	  }
    	  var fullName = $("#title").val() + $("#name").val(); 
          var data = $("#main").find("form") .serialize() +
            "&" + $("#payment").find("form").serialize();

          var storage = JSON.parse(localStorage.getItem("hotel_data"));
          data += "&price=" + storage.price;

          var config = {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            redirect: "follow",
            referrer: "no-referrer"
          };


          fetch("http://localhost:8080/addcustomer",
            Object.assign({}, config, { body: data })
          )
            .then(function(response) { return response.json(); })
            .then(function(res) {

            	async.each(storage.rooms, function(room, callback) {
            		var content = Object.assign({}, storage, {bref: res.bref, roomno: room})
                	fetch(
		              "http://localhost:8080/bookroom",
		              Object.assign({}, config, { body: $.param(content) })
		            )
		              .then(function(response) { return response.text();})
		              .then(function(res2) {
		                console.log(res2);
		                callback();
		              })
		              
                }, function(err) {
                	if(err) { console.log("Error", err); }
                	var sD = JSON.parse( localStorage.getItem("hotel_data") );
                	localStorage.setItem("hotel_data", 
                		JSON.stringify(Object.assign({}, sD, {bref: res.bref, name: fullName}) ));
                	location.assign("http://localhost:8080/confirm.html");
				});
			   
            })
            

          /* Book the food */
          if (storage.breakfast) {
            var bookData = JSON.parse(localStorage.getItem("hotel_data"));
            bookData.name = fullName;

            fetch(
              "http://localhost:8080/book",
              Object.assign({}, config, { body: $.param(bookData) })
            )
              .then(function(response) { return response.text();})
              .then(function(res) {
                console.log(res);
              })
              
          }
        });
      });