function saveForm(){
	var form1Data = {}; 			
	form1Data.account = $('#rec_account').val();	
	form1Data.password = $('#rec_psw').val();	
	
	// check we're getting what we hope for
	console.log('account =', form1Data.account);
	console.log('password =', form1Data.password);
	
	setObject('form1Data', form1Data);				// store the data locally
	var storedData = getObject('form1Data');		// get it back again...
	console.log('account =', storedData.account);	// check...
};


// for login page
function submitform(disp_id){
    var storedData;
    saveForm(); // save the form again just in case
    storedData = getObject('form1Data');
    post('http://localhost:8081/get_form', storedData, disp_id);
    
};

//for reception main page menu
function toBookingRoom(disp_id){
    window.location.replace('/BookingRoom_main.html');
};

function toOrderMeal(disp_id){
    window.location.replace('/OrderMeal_main.html');
};

function toReport(disp_id){
    window.location.replace('/Report_main.html');
};

function toBookingMeeting(disp_id){
    window.location.replace('/BookingMeeting_main.html');
};

function toSetting(disp_id){
    window.location.replace('/Setting.html');
};

// home page functionality
function getuserName(disp_id){
    var storedData;
    saveForm(); // save the form again just in case
    storedData = getObject('form1Data');
    post('http://localhost:8081/get_form', storedData, disp_id);
};

function post(path, data, disp_id) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);
    $.ajax({
        url: path,
        type: "POST",
        data: json,
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
			
			$('#'+disp_id).empty();
            $.each(json, function(i,val) {
                $('#'+disp_id).append(JSON.stringify(val) + "<br/>");
            })
            window.document.hi.innertext = data.account;
            window.location.replace('/reception_page.html');
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });
};