


var http = require('http');

http.createServer(function(req,res){
    res.setHeader('Access-Control-Allow-Origin', '*');
    switch (req.url) {
        case '/rec_login.html':
            break;
        case '/reception_page.html':
            break;
        case '/get_form':
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                    console.log("Partial body: " + body);
                });
                req.on('end', async function () {
                    console.log("Body: " + body);
                    var json = JSON.parse(body)
                    console.log("name is " + json.account) // get name
                    
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://postgres:e54030@localhost/HotelBooking';
                    
                    const client = new Client({connectionString: connectionString});
                    
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'SELECT * FROM hotelbooking.employee WHERE account = $1 AND password = $2 AND emp_job = $3';
                    const values = [json.account, json.password, 'Reception'];
                    const res2 = await client.query(text,values);
                    await client.end();
                    console.log("res2.rowCount: " + res2.rowCount);
                    if(res2.rowCount >0 ){
                        json = res2.rows;
                    }else{
                        json="unauthorized"
                    }
                    var json_str_new = JSON.stringify(json);
                    //res.writeHead(301, {'Location': 'http://'+req.headers['host']+'/reception_page.html'});
                    res.end(json_str_new)
                    
                });
            }
            break;
        case '/get_checkin':
            if (req.method == 'POST') {
   
            }
            break;
        case '/get_checkout':
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                    console.log("Partial body: " + body);
                });
                req.on('end', async function () {
                    console.log("Body: " + body);
                    var json = JSON.parse(body)
                    console.log("name is " + json.account) // get name
                    
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://postgres:XXXXXX@localhost/HotelBooking';
                    
                    const client = new Client({connectionString: connectionString});
                    
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'SELECT * FROM hotelbooking.employee WHERE account = $1 AND password = $2 AND emp_job = $3';
                    const values = [json.account, json.password, 'Reception'];
                    const res2 = await client.query(text,values);
                    await client.end();
                    console.log("res2.rowCount: " + res2.rowCount);
                    if(res2.rowCount >0 ){
                        json = res2.rows;
                    }else{
                        json="unauthorized"
                    }
                    var json_str_new = JSON.stringify(json);
                    //res.writeHead(301, {'Location': 'http://'+req.headers['host']+'/reception_page.html'});
                    res.end(json_str_new)
                    
                });
            }
            break;
        case '/get_customer_info':
            if (req.method == 'POST') {

            }
            break;
        case '/get_meal_data':
            if (req.method == 'POST') {

            }
            break;
        default:
            res.writeHead(200, {'Content-Type': 'text/html'});
            res.end('success');
    }
}).listen(8081);
