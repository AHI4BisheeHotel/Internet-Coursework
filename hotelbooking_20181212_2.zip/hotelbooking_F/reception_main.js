function saveForm(){
	var form1Data = {}; 			
	form1Data.account = $('#rec_account').val();	
	form1Data.password = $('#rec_psw').val();	
	setObject('form1Data', form1Data);				// store the data locally
	var storedData = getObject('form1Data');		// get it back again...
};


// for login page
function submitform(disp_id){
    var storedData;
    saveForm(); // save the form again just in case
    storedData = getObject('form1Data');
    rec_post('http://localhost:8081/get_form', storedData, disp_id,'rec_login');
    
};

function  gohome(disp_id){
    window.location.replace('/reception_page.html');
    
};

//for reception main page menu
function toBookingRoom(disp_id){
    window.location.replace('/rec_checking_page.html');
};

function toReport(disp_id){
    window.location.replace('/reception_report.html');
};


// home page functionality
function getuserName(disp_id){
    var storedData;
    saveForm(); // save the form again just in case
    storedData = getObject('form1Data');
    post('http://localhost:8081/get_form', storedData, disp_id);
};

function rec_post(path, data, disp_id,page_name) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);

    $.ajax({
        url: path,
        type: "POST",
        data: json,
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            $('#'+disp_id).empty();
            var str = "";
            $.each(json, function(i,val) {
                if(i==='status' && val ==='unauthorized'){
                    $('#'+disp_id).append('You have entered an invalid username or password');
                }else{
                    if(i ==='logininfo'){
                        $.each(val, function(x, val1) {
                            $.each(val1, function(y, val2) {
                                if(y==='emp_name'){
                                    str =y+"="+val2;
                                }
                            });
                        });
                    }
                    if(i ==='checkin＿all'){
                        $.each(val, function(x, val1) {
                            $.each(val1, function(y, val2) {
                                if(y==='cki_cun'){
                                    str +="&"+y+'_all'+"="+val2;
                                }
                            });
                        });
                    }
                    if(i ==='checkin＿i'){
                        $.each(val, function(x, val1) {
                            $.each(val1, function(y, val2) {
                                if(y==='cki_cun'){
                                    str +="&"+y+'_i'+"="+val2;
                                }
                            });
                        });
                    }
                    if(i ==='checkout_all'){
                        $.each(val, function(x, val1) {
                            $.each(val1, function(y, val2) {
                                if(y==='cko_cun'){
                                    str +="&"+y+'_all'+"="+val2;
                                }
                            });
                        });
                    }
                    if(i ==='checkout_o'){
                        $.each(val, function(x, val1) {
                            $.each(val1, function(y, val2) {
                                if(y==='cko_cun'){
                                    str +="&"+y+'_O'+"="+val2;
                                }
                            });
                        });
                    }
                    $('#gohome').append('/reception_page.html?'+str);
                    window.location.replace('/reception_page.html?'+str);
                }
                
            })
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });

};

//seachBooking
function seachBooking(disp_id){
    var storedData;
    saveForm(); // save the form again just in case
    storedData = getObject('form1Data');
    rec_post('http://localhost:8081/get_form', storedData, disp_id);
};

//report
function searchForm(){
	var form2Data = {}; 			
	form2Data.year = $('#year').val();	
	setObject('form2Data', form2Data);				// store the data locally
};

function post_income(disp_id){
    var storedData;
    searchForm(); // save the form again just in case
    storedData = getObject('form2Data');
    get_income('http://localhost:8081/get_income', storedData);
    
};


function get_income(path, data) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);

    $.ajax({
        url: path,
        type: "POST",
        data: json,
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            var str = "";
            $('#income_table').empty();
            $('#res').empty();
            var y=0;
            $.each(json, function(k,value1) {
                y++;
                var col = [];
                for (var k = 0; k < value1.length; k++) {
                    for (var key in value1[k]) {
                        if (col.indexOf(key) === -1) {
                            col.push(key);
                        }
                    }
                }
                    var table = document.createElement("table");
                    table.style.border="2px solid ";
                    table.style.borderColor="#B4955E";
                    table.width="100%";
                    var tr = table.insertRow(-1);           
            
                    for (var i = 0; i < col.length; i++) {
                        var th = document.createElement("th");   
                        th.innerHTML = col[i].toUpperCase();
                        th.style.backgroundColor="#B4955E";
                        th.style.border="2px solid ";
                        th.style.borderColor="#B4955E";
                        th.style.color="#ffffff";
                        tr.appendChild(th);
                        tr.style.backgroundColor="#ffffff";
                        tr.style.border="2px solid ";
                        tr.style.borderColor="#B4955E";
                    }
                    tr.appendChild(th);
                    for (var i = 0; i < value1.length; i++) {
                        tr = table.insertRow(-1);
                        for (var j = 0; j < col.length; j++) {
                            var tabCell = tr.insertCell(-1);
                            tabCell.style.backgroundColor="#ffffff";
                            tabCell.style.border="1px solid ";
                            tabCell.style.borderColor="#B4955E";
                            tabCell.style.color="#000000";
                            tabCell.innerHTML = value1[i][col[j]];
                                
                        } 
                    }
                var divContainer = document.getElementById("income_table");
                divContainer.innerHTML = "";
                divContainer.appendChild(table);
            })
            if(y==0){
                $('#res').append('No reault');
            }
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });

};

function searchoccupancyForm(){
	var form3Data = {}; 			
    form3Data.year = $('#year_o').val();
	setObject('form3Data', form3Data);				// store the data locally
};


//post_occupancy
function post_occupancy(disp_id){
    var storedData;
    searchoccupancyForm(); // save the form again just in case
    storedData = getObject('form3Data');
    get_occupancy('http://localhost:8081/get_occupancy', storedData);
    
};


function get_occupancy(path, data) {
    // convert the parameters to a JSON data string
    var json = JSON.stringify(data);

    $.ajax({
        url: path,
        type: "POST",
        data: json,
        success: function(rt) {
            // returned data
            var json = JSON.parse(rt); // the returned data will be an array
            var str = "";
            $('#occupancy_table').empty();
            $('#occupancy_res').empty();
            var y=0;
            $.each(json, function(k,value1) {
                y++;
                var col = [];
                for (var k = 0; k < value1.length; k++) {
                    for (var key in value1[k]) {
                        if (col.indexOf(key) === -1) {
                            col.push(key);
                        }
                    }
                }
                    var table = document.createElement("table");
                    table.style.border="2px solid ";
                    table.style.borderColor="#B4955E";
                    table.width="100%";
                    var tr = table.insertRow(-1);           
            
                    for (var i = 0; i < col.length; i++) {
                        var th = document.createElement("th");   
                        th.innerHTML = col[i].toUpperCase();
                        th.style.backgroundColor="#B4955E";
                        th.style.border="2px solid ";
                        th.style.borderColor="#B4955E";
                        th.style.color="#ffffff";
                        tr.appendChild(th);
                        tr.style.backgroundColor="#ffffff";
                        tr.style.border="2px solid ";
                        tr.style.borderColor="#B4955E";
                    }
                    tr.appendChild(th);
                    for (var i = 0; i < value1.length; i++) {
                        tr = table.insertRow(-1);
                        for (var j = 0; j < col.length; j++) {
                            var tabCell = tr.insertCell(-1);
                            tabCell.style.backgroundColor="#ffffff";
                            tabCell.style.border="1px solid ";
                            tabCell.style.borderColor="#B4955E";
                            tabCell.style.color="#000000";
                            tabCell.innerHTML = value1[i][col[j]];
                                
                        } 
                    }
                var divContainer = document.getElementById("occupancy_table");
                divContainer.innerHTML = "";
                divContainer.appendChild(table);
            })
            if(y==0){
                $('#occupancy_res').append('No reault');
            }
        },
        error: function(){
            alert("System error,Please check your code");
        }
    });

};
