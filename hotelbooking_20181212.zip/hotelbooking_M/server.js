var http = require('http');
var path = require('path');
var fs = require("fs");
var db = require("./db");
var qs = require('querystring');
var uniqueRandom = require('unique-random');
var rand = uniqueRandom(100, 1000000);
var rand2 = uniqueRandom(100, 1000000);

http.createServer(function(req,res){
    //start Reception part ----Ada
    res.setHeader('Access-Control-Allow-Origin', '*');
    body = "";
    switch (req.url) {
        case '/rec_login.html':
            break;
        case '/reception_page.html':
            break;
        case '/get_form':
            if (req.method == 'POST') {
                var body = '';
                 req.on('data', function (data) {
                     body += data;
                });
                req.on('end', async function () {
                    var json = JSON.parse(body)
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    
                    const client = new Client({connectionString: connectionString});
                    
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'SELECT * FROM hotelbooking.employee WHERE account = $1 AND password = $2 AND emp_job = $3';
                    const values = [json.account, json.password, 'Reception'];
                    const res2 = await client.query(text,values);


                    const text1 = 'select  count(*) cki_cun from hotelbooking.booking a,hotelbooking.roombooking b '+
                                  ' where a.b_ref = b.b_ref and b.checkin = current_date group by b.checkin ';
                    const res3 = await client.query(text1);

                    const text2 = 'select  count(*) cki_cun from hotelbooking.booking a,hotelbooking.roombooking b '+
                                  ' where a.b_ref = b.b_ref and b.checkin = current_date and b.b_status=$1 group by b.b_status';
                    const values2 = ['B'];          
                    const res4 = await client.query(text2,values2);
 
                    const text3 = 'select  count(*) cko_cun from hotelbooking.booking a,hotelbooking.roombooking b '+
                                    ' where a.b_ref = b.b_ref and b.checkout = current_date group by b.checkout';          
                    const res5 = await client.query(text3);                    
                    const text4 = 'select  count(*) cko_cun from hotelbooking.booking a,hotelbooking.roombooking b '+
                                    ' where a.b_ref = b.b_ref and b.checkout = current_date and b.b_status=$1  group by b.b_status';
                    const values4 = ['I'];                 
                    const res6 = await client.query(text4,values4);
                    await client.end();
                    var dataset = {}; 
                    if(res2.rowCount > 0 ){
                        dataset.logininfo = res2.rows;
                        dataset.checkin＿all = res3.rows;
                        dataset.checkin＿i = res4.rows;
                        dataset.checkout_all = res5.rows;
                        dataset.checkout_o = res6.rows;
                    }else{
                        dataset.status='unauthorized';
                    }
                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
        case '/get_havenotchkin':
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });
                req.on('end', async function () {
                    var json = JSON.parse(body)
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    
                    const client = new Client({connectionString: connectionString});
                    
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'SELECT a.b_ref BOOKING_ID,d.c_no CUSTOMER_ID,d.c_name CUSTOMER_NAME,case WHEN e.r_class = $1 then $2 WHEN e.r_class = $3 then $4 '+ 
                                ' WHEN e.r_class = $5 then $6 WHEN e.r_class = $7 then $8 end ROOM_TYPE,count(a.b_ref) AMOUNT ,c.b_status STATUS '+
                                'FROM hotelbooking.booking a,hotelbooking.customer d,hotelbooking.roombooking C,hotelbooking.room e '+
                                'where a.b_ref = c.b_ref and a.c_no = d.c_no '+
                                'and c.checkin = current_date and c.r_no = e.r_no '+
                                'group by a.b_ref,d.c_no,d.c_name,e.r_class,c.b_status ';
                    const values = ['sup_t','Superior Twin','std_d','Standard Double','std_t','Standard Twin','sup_d','Superior Double'];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }
                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/get_defaultCheckData':
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });
                req.on('end', async function () {
                    var json = JSON.parse(body)
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    
                    const client = new Client({connectionString: connectionString});
                    
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'SELECT a.b_ref BOOKING_ID,d.c_no CUSTOMER_ID,d.c_name CUSTOMER_NAME,case WHEN e.r_class = $1 then $2 WHEN e.r_class = $3 then $4 '+ 
                                ' WHEN e.r_class = $5 then $6 WHEN e.r_class = $7 then $8 end ROOM_TYPE ,count(a.b_ref) AMOUNT ,c.b_status STATUS '+
                                'FROM hotelbooking.booking a,hotelbooking.customer d,hotelbooking.roombooking C,hotelbooking.room e '+
                                'where a.b_ref = c.b_ref and a.c_no = d.c_no '+
                                'and c.checkin = current_date and c.r_no = e.r_no '+
                                'group by a.b_ref,d.c_no,d.c_name,e.r_class,c.b_status ';
                    const values = ['sup_t','Superior Twin','std_d','Standard Double','std_t','Standard Twin','sup_d','Superior Double'];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }
                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/get_havenotchkin':
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });
                req.on('end', async function () {
                    var json = JSON.parse(body)
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    
                    const client = new Client({connectionString: connectionString});
                    
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'SELECT a.b_ref BOOKING_ID,d.c_no CUSTOMER_ID,d.c_name CUSTOMER_NAME,case WHEN e.r_class = $1 then $2 WHEN e.r_class = $3 then $4 '+ 
                                ' WHEN e.r_class = $5 then $6 WHEN e.r_class = $7 then $8 end ROOM_TYPE,count(a.b_ref) AMOUNT ,c.b_status STATUS '+
                                'FROM hotelbooking.booking a,hotelbooking.customer d,hotelbooking.roombooking C,hotelbooking.room e '+
                                'where a.b_ref = c.b_ref and a.c_no = d.c_no and c.b_status=$8 '+
                                'and c.checkin = current_date and c.r_no = e.r_no '+
                                'group by a.b_ref,d.c_no,d.c_name,e.r_class,c.b_status ';
                    const values = ['sup_t','Superior Twin','std_d','Standard Double','std_t','Standard Twin','sup_d','Superior Double','B'];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }
                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/get_dchkoutData':
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });
                req.on('end', async function () {
                    var json = JSON.parse(body)
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    
                    const client = new Client({connectionString: connectionString});
                    
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'SELECT a.b_ref BOOKING_ID,d.c_no CUSTOMER_ID,d.c_name CUSTOMER_NAME,case WHEN e.r_class = $1 then $2 WHEN e.r_class = $3 then $4 '+ 
                                 ' WHEN e.r_class = $5 then $6 WHEN e.r_class = $7 then $8 end ROOM_TYPE ,count(a.b_ref) AMOUNT ,c.b_status STATUS '+
                                'FROM hotelbooking.booking a,hotelbooking.customer d,hotelbooking.roombooking C,hotelbooking.room e '+
                                'where a.b_ref = c.b_ref and a.c_no = d.c_no '+
                                'and c.checkout = current_date and c.r_no = e.r_no '+
                                'group by a.b_ref,d.c_no,d.c_name,e.r_class,c.b_status ';
                    const values = ['sup_t','Superior Twin','std_d','Standard Double','std_t','Standard Twin','sup_d','Superior Double'];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }
                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/get_havenotchkout':
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });
                req.on('end', async function () {
                    var json = JSON.parse(body)
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    
                    const client = new Client({connectionString: connectionString});
                    
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'SELECT a.b_ref BOOKING_ID,d.c_no CUSTOMER_ID,d.c_name CUSTOMER_NAME,case WHEN e.r_class = $1 then $2 WHEN e.r_class = $3 then $4 '+ 
                                 ' WHEN e.r_class = $5 then $6 WHEN e.r_class = $7 then $8 end ROOM_TYPE,count(a.b_ref) AMOUNT ,c.b_status STATUS '+
                                'FROM hotelbooking.booking a,hotelbooking.customer d,hotelbooking.roombooking C,hotelbooking.room e '+
                                'where a.b_ref = c.b_ref and a.c_no = d.c_no '+
                                'and c.checkout = current_date and c.r_no = e.r_no and c.b_status=$9 '+
                                'group by a.b_ref,d.c_no,d.c_name,e.r_class,c.b_status ';
                    const values = ['sup_t','Superior Twin','std_d','Standard Double','std_t','Standard Twin','sup_d','Superior Double','I'];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }
                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/get_dchkoutData':
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });
                req.on('end', async function () {
                    var json = JSON.parse(body)
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    
                    const client = new Client({connectionString: connectionString});
                    
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'SELECT a.b_ref BOOKING_ID,d.c_no CUSTOMER_ID,d.c_name CUSTOMER_NAME,case WHEN e.r_class = $1 then $2 WHEN e.r_class = $3 then $4 '+ 
                                ' WHEN e.r_class = $5 then $6 WHEN e.r_class = $7 then $8 end ROOM_TYPE ,count(a.b_ref) AMOUNT ,c.b_status STATUS '+
                                'FROM hotelbooking.booking a,hotelbooking.customer d,hotelbooking.roombooking C,hotelbooking.room e '+
                                'where a.b_ref = c.b_ref and a.c_no = d.c_no '+
                                'and c.checkin = current_date and c.r_no = e.r_no '+
                                'group by a.b_ref,d.c_no,d.c_name,e.r_class,c.b_status ';
                    const values = ['sup_t','Superior Twin','std_d','Standard Double','std_t','Standard Twin','sup_d','Superior Double'];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }
                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
        case '/search_room':
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });
                req.on('end', async function () {
                    var json = JSON.parse(body)
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    const client = new Client({connectionString: connectionString});
                    console.log('here')
                    await client.connect(); // create a database connection
                    var type = json.stype;
                    var values ;
                    var text1 ="";
                    if(json.sdata!=""){
                        text1 = 'SELECT a1.b_ref BOOKING_ID,d.c_no CUSTOMER_ID,d.c_name CUSTOMER_NAME,case WHEN e.r_class = $4 then $5 WHEN e.r_class = $6 then $7 '+ 
                        ' WHEN e.r_class = $8 then $9 WHEN e.r_class = $10 then $11 end ROOM_TYPE ,count(a1.b_ref) AMOUNT '+
                        'FROM (select * from hotelbooking.booking a '+
                        'where a.b_ref = $1 or a.c_no = '+
                        '(select c_no from hotelbooking.customer where c_name = $2) '+
                        'or a.b_ref = (select b_ref from hotelbooking.roombooking where r_no = $3 and current_date between checkin  and  checkout)) a1 '+
                        'left join hotelbooking.customer d on a1.c_no = d.c_no   '+
                        'left join hotelbooking.roombooking b on a1.b_ref = b.b_ref '+
                        'left join hotelbooking.room e on b.r_no = e.r_no '+
                        'group by a1.b_ref,d.c_no,d.c_name,e.r_class,b.checkin order by b.checkin asc';
                        values = [json.sdata, json.sdata,  json.sdata,'sup_t','Superior Twin','std_d','Standard Double','std_t','Standard Twin','sup_d','Superior Double'];

                    }else{
                        text1 = 'SELECT a1.b_ref BOOKING_ID,d.c_no CUSTOMER_ID,d.c_name CUSTOMER_NAME, '+
                                    'case WHEN e.r_class = $1 then $2 WHEN e.r_class = $3 then $4 '+ 
                                    ' WHEN e.r_class = $5 then $6 WHEN e.r_class = $7 then $8 end ROOM_TYPE ,'+
                                    'count(a1.b_ref) AMOUNT  '+
                                    'FROM (select * from hotelbooking.booking a   '+
                                    'where a.b_ref in (select b_ref from hotelbooking.roombooking where current_date between checkin  and  checkout)) a1   '+
                                    'left join hotelbooking.customer d on a1.c_no = d.c_no  '+
                                    'left join hotelbooking.roombooking b on a1.b_ref = b.b_ref   '+
                                    'left join hotelbooking.room e on b.r_no = e.r_no  '+ 
                                    'group by a1.b_ref,d.c_no,d.c_name,e.r_class,b.checkin order by b.checkin asc';
                        values = ['sup_t','Superior Twin','std_d','Standard Double','std_t','Standard Twin','sup_d','Superior Double'];
                    }
                    const text = text1;
                    const res2 = await client.query(text,values);
                    await client.end();
                    console.log("res2.rowCount: " + res2.rowCount);
                    if(res2.rowCount >0 ){
                        json.checkindata = res2.rows;
                    }else{
                        json.status="datanotfound";
                    }
                    var json_str_new = JSON.stringify(json);
                    res.end(json_str_new);
                });
            }
        break;
        case '/get_checkout':
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                    console.log("Partial body: " + body);
                });
                req.on('end', async function () {
                    console.log("Body: " + body);
                    var json = JSON.parse(body)
                    console.log("name is " + json.account) // get name
                    
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    
                    const client = new Client({connectionString: connectionString});
                    
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'SELECT'+
                    'a1.b_ref,d.c_no,d.c_name,case WHEN e.r_class = $4 then $5 WHEN e.r_class = $6 then $7 '+ 
                    ' WHEN e.r_class = $8 then $9 WHEN e.r_class = $10 then $11 end ROOM_TYPE ,count(a1.b_ref)'+
                    'FROM (select * from hotelbooking.booking a '+
                    'where a.b_ref =$1 or a.c_no = '+
                    '(select c_no from hotelbooking.customer where c_name = $2)'+
                    'or a.b_ref = (select b_ref from hotelbooking.roombooking where r_no = $3 and current_date between checkin  and  checkout)) a1'+
                    'left join hotelbooking.customer d on a1.c_no = d.c_no   '+
                    'left join hotelbooking.roombooking b on a1.b_ref = b.b_ref '+
                    'left join hotelbooking.room e on b.r_no = e.r_no'+
                    'group by a1.b_ref,d.c_no,d.c_name,e.r_class';
                    const values = [json.account, json.password, 'Reception','sup_t','Superior Twin','std_d','Standard Double','std_t','Standard Twin','sup_d','Superior Double'];
                    const res2 = await client.query(text,values);
                    await client.end();
                    console.log("res2.rowCount: " + res2.rowCount);
                    if(res2.rowCount >0 ){
                        json = res2.rows;
                    }else{
                        json="unauthorized"
                    }
                    var json_str_new = JSON.stringify(json);
                    //res.writeHead(301, {'Location': 'http://'+req.headers['host']+'/reception_page.html'});
                    res.end(json_str_new)
                    
                });
            }
            break;
        case '/get_bookingdetail':     
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });     
                req.on('end', async function () {
                    var json = JSON.parse(body);   
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    const client = new Client({connectionString: connectionString});
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'SELECT '+
                                'a.b_ref BOOKING_NO,d.c_no CUSTOMER_ID,d.c_name CUSTOMER_NAME,case WHEN e.r_class = $4 then $5 WHEN e.r_class = $6 then $7 '+ 
                                ' WHEN e.r_class = $8 then $9 WHEN e.r_class = $10 then $11 end ROOM_TYPE ,e.r_no ROOM_NO,d.c_email EMAIL, '+
                                'd.c_address ADDRESS,f.fb_name FOOD_NAME,f.amount AMOUNT,f.amount*c.f_price TOTAL_FOOD_PRICE, '+
                                'TO_CHAR(b.checkin,$2) CHECK_IN, TO_CHAR(b.checkout,$3) CHECK_OUT, b.checkout-b.checkin DUERATION, '+
                                'e.r_status ROOM_STATUS,b.b_status BOOKING_STATUS '+
                                'FROM hotelbooking.booking a  '+
                                'left join hotelbooking.roombooking b on a.b_ref = b.b_ref  '+
                                'left join hotelbooking.customer d on a.c_no = d.c_no '+
                                'left join hotelbooking.room e on b.r_no = e.r_no '+
                                'left join hotelbooking.foodbooking f on f.b_ref = a.b_ref and f.r_no = b.r_no '+
                                'left join hotelbooking.food c on c.f_id = f.f_id '+ 
                                'where a.b_ref =$1 ';    
                    const text1 = 'select case when a.b_outstanding > 0 then $2 ELSE $3 END STATUS FROM hotelbooking.booking a where a.b_ref = $1';    
                    const values = [json.detailid,'YYYY-MM-DD','YYYY-MM-DD','sup_t','Superior Twin','std_d','Standard Double','std_t','Standard Twin','sup_d','Superior Double'];         
                    const values1 = [json.detailid,'NOT YET PAID','PAID'];
                    const res1 = await client.query(text,values);
                    const res2 = await client.query(text1,values1);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                        dataset.paidstatus = res2.rows;
                    }
                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/get_meal_data':
            if (req.method == 'POST') {

            }
            break;
            case '/change_room':     
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });     
                req.on('end', async function () {
                    var json = JSON.parse(body);   
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    const client = new Client({connectionString: connectionString});
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'select a.r_no ROOM_NO,case WHEN a.r_class = $7 then $8 WHEN a.r_class = $9 then $10 '+ 
                                ' WHEN a.r_class = $11 then $12 WHEN a.r_class = $13 then $14 end ROOM_TYPE , '+
                                ' a.r_status ROOM_STATUS from hotelbooking.room a '+
                                'where a.r_no not in  '+
                                '(select r_no from hotelbooking.roombooking b  '+
                                ' where ( '+
                                '(select a1.checkin from hotelbooking.roombooking a1 where a1.b_ref = $1 and r_no = $2)  '+
                                'between b.checkin and b.checkout)and  '+
                                '((select a1.checkout from hotelbooking.roombooking a1 where a1.b_ref = $3 and r_no = $4)  '+
                                ' between b.checkin and b.checkout) '+
                                ') and r_status in ($5,$6) order by a.r_no,a.r_class';          
                    const values = [json.col_b_ref,json.col_r_no,json.col_b_ref,json.col_r_no,'A','C','sup_t','Superior Twin','std_d','Standard Double','std_t','Standard Twin','sup_d','Superior Double'];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }
                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/checkin':     
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });     
                req.on('end', async function () {
                    var json = JSON.parse(body);   
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    const client = new Client({connectionString: connectionString});
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'update hotelbooking.roombooking set b_status =$1 where b_ref = $2 and r_no=$3';   
                    const text1 = 'update hotelbooking.room set r_status =$1 where r_no=$2';          
                    const values = ['I',json.col_b_ref,json.col_r_no];
                    const values1 = ['X',json.col_r_no];
                    const res1 = await client.query(text,values);
                    const res2 = await client.query(text1,values1);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }

                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/checkout':     
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });     
                req.on('end', async function () {
                    var json = JSON.parse(body);   
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    const client = new Client({connectionString: connectionString});
                    await client.connect(); // create a database connection
                    const text = 'update hotelbooking.roombooking set b_status =$1,checkout = current_date where b_ref = $2 and r_no=$3';   
                    const text1 = 'update hotelbooking.room set r_status =$1 where r_no=$2';          
                    const values = ['O',json.chko_b_ref,json.chko_r_no];
                    const values1 = ['C',json.chko_r_no];
                    const res1 = await client.query(text,values);
                    const res2 = await client.query(text1,values1);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }

                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/switchroom':     
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });     
                req.on('end', async function () {
                    var json = JSON.parse(body);   
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    const client = new Client({connectionString: connectionString});
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'update hotelbooking.roombooking set r_no =$1 where b_ref = $2 and r_no=$3 ';
                    const text2= 'update hotelbooking.foodbooking set r_no =$1 where b_ref = $2 and r_no=$3 ';   
                    const text3 = 'update hotelbooking.room set r_status =$1 where r_no=$2'; 
                    const text4 = 'update hotelbooking.room set r_status =$1 where r_no=$2';          
                    
                    const values = [json.to_r_no,json.col_b_ref,json.col_r_no];
                    const values1 = ['A',json.col_r_no];
                    const values2 = ['X',json.to_r_no];    
                    const res1 = await client.query(text,values);
                    const res2 = await client.query(text2,values);
                    const res3 = await client.query(text3,values1);
                    const res4 = await client.query(text4,values2);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }

                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/pay_room':     
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });     
                req.on('end', async function () {
                    var json = JSON.parse(body);   
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    const client = new Client({connectionString: connectionString});
                    await client.connect(); // create a database connection
                    const text = 'select aa.b_ref BOOKING_NO,aa.b_outstanding BILL, '+
                                '(case when bb.food_price is null then 0 else bb.food_price end) as food_price, '+
                                'aa.b_outstanding+(case when bb.food_price is null then 0 else bb.food_price end) total_price from ( '+
                                'select a.b_ref,a.b_outstanding from hotelbooking.booking a '+
                                'left join (select c.b_ref,c.amount*c1.f_price food_price,c1.f_name,c.amount,c1.f_price  '+
                                'from hotelbooking.foodbooking c,hotelbooking.food c1 where c.f_id = c1.f_id) cc '+ 
                                'on a.b_ref = cc.b_ref) aa '+
                                'left join  '+
                                '(select c.b_ref,sum(c.amount*c1.f_price) food_price '+
                                'from hotelbooking.foodbooking c,hotelbooking.food c1  '+
                                'where c.f_id = c1.f_id  '+
                                'group by c.b_ref)bb '+
                                'on aa.b_ref = bb.b_ref  '+
                                'where aa.b_ref = $1 ';        

                    const values = [json.pay_b_ref];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.pay_info = res1.rows;
                    }
                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/paid':     
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                });     
                req.on('end', async function () {
                    var json = JSON.parse(body);   
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    const client = new Client({connectionString: connectionString});
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'update hotelbooking.roombooking set B_STATUS =$1 where b_ref = $2 ';  
                    const text1 = 'update hotelbooking.room set r_status =$1 where r_no IN (SELECT R_NO  FROM HOTELBOOKING.ROOMBOOKING A WHERE A.B_REF = $2  )'; 
                    const text2 = 'update hotelbooking.booking set b_outstanding = $1 where b_ref = $2';
                    const values = ['B',json.pay_b_ref];
                    const values1 = ['C',json.pay_b_ref]; 
                    const values2 = [0,json.pay_b_ref]; 
                    const res1 = await client.query(text,values);
                    const res2 = await client.query(text1,values1);
                    const res3 = await client.query(text2,values2);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }
                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/get_income':     
            if (req.method == 'POST') {
                var body = '';
                console.log('get_income');

                req.on('data', function (data) {
                    body += data;
                });     
                req.on('end', async function () {
                    var json = JSON.parse(body);   
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    const client = new Client({connectionString: connectionString});
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'select sum(a.b_cost)  TOTAL_ROOM_INCOME,  sum(c.amount*d.f_price) TOTAL_FOOD_INCOME,sum(a.b_cost)+ '+
                                 '(CASE WHEN sum(c.amount*d.f_price) is NULL THEN 0 else sum(c.amount*d.f_price) END) Revenue '+
                                'from hotelbooking.booking a '+
                                'left join hotelbooking.roombooking b on a.b_ref = b.b_ref '+
                                'left join hotelbooking.foodbooking c on a.b_ref = c.b_ref '+
                                'left join hotelbooking.food d on d.f_id = c.f_id '+
                                'where a.b_outstanding = 0 and b.checkout < current_date '+
                                'and EXTRACT(year FROM b.checkout) = $1 '+
                                'group by EXTRACT(year FROM b.checkout)';  

                    const values = [json.year];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.allcheckintable = res1.rows;
                    }

                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            case '/get_occupancy':     
            if (req.method == 'POST') {
                var body = '';
                console.log('get_occupancy');
                req.on('data', function (data) {
                    body += data;
                });     
                req.on('end', async function () {
                    var json = JSON.parse(body);   
                    const {Client} = require('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
                    const client = new Client({connectionString: connectionString});
                    await client.connect(); // create a database connection
                    //checking account is exist
                    const text = 'select b1.months _Month,round( cast ( b1.days as numeric )/ cast( a1.total_room as numeric),2)%100 occupancy_Rate  from ( '+
                                'select sum(b.checkout-b.checkin) days,EXTRACT(month FROM b.checkin) months '+
                                'from hotelbooking.roombooking b  '+
                                'where EXTRACT(year FROM b.checkin) = $1 '+
                                'group by EXTRACT(month FROM b.checkin) '+
                                ') b1, '+
                                '(SELECT count(a.r_no)*30 total_room FROM hotelbooking.room A) a1 '+
                                'order by b1.months';  

                    const values = [json.year];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var dataset = {}; 
                    if(res1.rowCount > 0 ){
                        dataset.occupancy = res1.rows;
                    }

                    var json_str_new = JSON.stringify(dataset);
                    res.end(json_str_new)
                    
                });
            }
            break;
            //end Reception part ----Ada
            //start housekeeper part ----Holly
            case '/change_status':
            if (req.method == 'POST') {
                console.log("POST");
                var body = '';
                req.on('data', function (data) {
                    body += data;
                    console.log("Partial body: " + body);
                });
                req.on('end', async function () {
                    console.log("Body: " + body);
                    var json = JSON.parse(body);
                    console.log("room number is " + json.roomNumber); //print roomNumber
                    console.log("status is " + json.roomStatus); //print status
                    json_str_new = JSON.stringify(json);
					const {Client} = require ('pg');
					const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';
					const client = new Client({ 
					connectionString: connectionString
                    });
                    
					await client.connect();
					const text = 'UPDATE hotelbooking.room SET r_status= $1 WHERE r_no = $2 RETURNING *';
                    const values = [json.roomStatus, json.roomNumber];
                    const res1 = await client.query(text,values);
                    await client.end();
                    var json_str_new = JSON.stringify(json);        
                    console.log(json_str_new);
                    res.end(json_str_new); // return modified data
					
                });
                
            }
            break;
            case '/get_status':
            if (req.method == 'GET') {
                console.log('get_status');
                var body = '';
                req.on('data', function (data) {
                    body += data;
                    console.log("Partial body: " + body);
                });
                req.on('end', async function () {
                    var json ;
                    const {Client} = require ('pg');
                    const connectionString = 'postgresql://groupbe:groupbe@cmp-18stunode.cmp.uea.ac.uk/groupbe';

                    const client = new Client({ 
                    connectionString: connectionString
                    });
                    await client.connect();
                    const res2 = await client.query('SELECT r_status , r_no FROM hotelbooking.room');
                    
                    await client.end();
                    json = res2.rows;
                    var json_str = JSON.stringify(json);        
                    res.end(json_str); // return modified data
                });
            }
            break;
            //end housekeeper part ----Holly
            //start website part ----Ika
            case "/addcustomer":
                res.writeHead(200, {
                "Content-Type": "application/json"
                });

                body = "";

                req.on("data", chunk => {
                body += chunk.toString();
                });

                req.on("end", () => {
                body = qs.parse(body);
                console.log(req.url + "  " + JSON.stringify(body) + "\n");

                const cno = rand();

                db.query(
                    `INSERT INTO hotelbooking.customer (c_no, c_name,c_email,c_address,c_cardtype,c_cardexp,c_cardno) 
                            VALUES($1,$2,$3,$4,$5,$6,$7)`,
                    [cno, (body.title + body.name), body.email,body.address,body.cardtype,body.cardexpiry,body.cardnumber],
                    (err, result) => {
                    if (!err) {
                        const bref = rand2();

                        db.query(
                        `INSERT INTO hotelbooking.booking (b_ref, c_no, b_cost, b_outstanding, b_notes) 
                                    VALUES($1,$2,$3,$4,$5)`,
                        [bref, cno, body.price, body.price, ""],
                        (err, result) => {
                            if (!err) {
                            res.end(
                                JSON.stringify({
                                bref: bref
                                })
                            );
                            } else {
                            res.end("{'success': false}");
                            console.log(err);
                            }
                        }
                        );
                    } else {
                        res.end("{success: false}");
                        console.log(err);
                    }
                    }
                );
                });
                break;
            case "/book":
                res.writeHead(200, {
                "Content-Type": "application/json"
                });
                body = "";

                req.on("data", chunk => {
                body += chunk.toString();
                });

                req.on("end", () => {
                body = qs.parse(body);
                console.log(req.url + "  " + JSON.stringify(body) + "\n");

                db.query(
                    "INSERT INTO hotelbooking.food (f_name, d_description, f_price) VALUES($1, $2, $3)",
                    ["breakfast", "breakfast", 10],
                    function(err, result) {
                    if (!err) {
                        res.end("{success: true}");
                    } else {
                        res.end("{success: false}");
                        console.log(err);
                    }
                    }
                );
                });

                break;
            case "/bookroom":
                res.writeHead(200, {
          "Content-Type": "application/json"
        });
        body = "";

        req.on("data", chunk => {
          body += chunk.toString();
        });

        req.on("end", () => {
          body = qs.parse(body);
          console.log(req.url + "  " + JSON.stringify(body) + "\n");

          db.query(
            `INSERT INTO hotelbooking.roombooking (r_no, b_ref, checkin, checkout, b_status) 
                    VALUES($1,$2,$3,$4, $5)`,
            [body.roomno, body.bref, body.checkindate, body.checkoutdate, "B"],
            (err, result) => {
              if (!err) {
                db.query(`UPDATE hotelbooking.room SET no_of_people=$1,r_status='A' WHERE r_no=$2`,
                  [Number(body.adultcount), body.roomno],
                  (err, result) => {
                    if (!err) {
                      if(body.breakfast == true || body.breakfast == 'true') {
                        db.query(
                          "INSERT INTO hotelbooking.foodbooking (f_id,fb_name,r_no,b_ref,amount) VALUES($1,$2,$3,$4,$5)",
                          [2, "breakfast", body.roomno, body.bref, body.numberOfRooms],
                          function(err, result) {
                            if (!err) {
                              res.end("{'success': true, 'action': 'booking/roombooking/foodbooking'}");
                            } else {
                              res.end("{success: false}");
                              console.log(err);
                            }
                          }
                        );
                      } else {
                        res.end("{'success': true, 'action': 'booking/roombooking'}");
                      }
                    } else {
                      res.end("{'success': false}");
                      console.log(err);
                    }
                  }
                );
              } else {
                res.end("{'success': false}");
                console.log(err);
              }
            }
          );
        });
                break;
            case "/check":
                res.writeHead(200, {
    'Content-Type': 'application/json'
});

body = '';

req.on('data', chunk => {
    body += chunk.toString();
});

req.on('end', () => {
    body = qs.parse(body);
    console.log(req.url + "  "+ JSON.stringify(body) + '\n');

    const query = `SELECT room.r_no,room.r_class,rates.price,roombooking.checkin::text,roombooking.checkout::text from hotelbooking.room
      INNER JOIN hotelbooking.rates ON rates.r_class=room.r_class
      FULL OUTER JOIN hotelbooking.roombooking ON roombooking.r_no=room.r_no`;  

    db.query(query, [], function (err, result) {
        if (! err) {
            const isBetweenDate = (dateFrom, dateTo, dateCheck) => {
                var from = new Date(dateFrom);  // -1 because months are from 0 to 11
                var to   = new Date(dateTo);
                var check = new Date(dateCheck);
                return (check >= from && check < to);
            };
            const passed = [];
            const rejected = [];

            let finalResult = result.rows.filter((row) => {
                if(row.checkin == null) {
                    passed.push(row.r_no); return true;
                } else if (passed.indexOf(row.r_no) > -1) {
                    rejected.push(row.r_no); 
                    return false;
                } else if( isBetweenDate(row.checkin, row.checkout, body.checkindate) || 
                        isBetweenDate(row.checkin, row.checkout, body.checkoutdate) ) {
                    rejected.push(row.r_no); 
                    return false;
                } else {
                    passed.push(row.r_no); return true;
                }
            });

            finalResult = finalResult.filter((row) => rejected.indexOf(row.r_no) < 0);

            var grouped = finalResult.reduce(function (r, a) {
                r[a.r_class] = r[a.r_class] || [];
                r[a.r_class].push(a);
                return r;
            }, Object.create(null));

            res.end(JSON.stringify(grouped));
        } else {
            console.log(err);
            res.end(JSON.stringify({
                status: 'error'
            }));
        }
    });
});
        break;
        //end website part ----Ika
        default:
            res.writeHead(200, {'Content-Type': 'text/html'});
            res.end('Hello groupbe');
    }

}).listen(8081);
